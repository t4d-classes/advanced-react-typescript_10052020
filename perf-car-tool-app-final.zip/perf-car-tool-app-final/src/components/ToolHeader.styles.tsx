import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles({
  header: {
    backgroundColor: 'navy',
    color: 'white',
    padding: 12,
  },
  text: {},
});