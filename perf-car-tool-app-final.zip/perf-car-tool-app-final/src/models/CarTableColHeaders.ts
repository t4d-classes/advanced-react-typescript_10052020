import { CarKeys } from './Car';

export type CarTableColHeaders = {
  id: number;
  col: CarKeys;
  caption: string;
}[];
