export type ConfirmDeleteCarMessage = {
  message: string;
  carId: number;
};
