export type ItemId = number;

export type Item = {
  id: ItemId;
};
